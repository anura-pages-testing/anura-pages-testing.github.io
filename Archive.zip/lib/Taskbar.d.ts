declare class Taskbar {
    #private;
    state: {
        pinnedApps: App[];
        activeApps: App[];
        showBar: boolean;
        time: string;
        bat_icon: string;
    };
    dragged: null;
    insidedrag: boolean;
    element: any;
    shortcut(app: App): any;
    showcontext(app: App, e: MouseEvent): void;
    constructor();
    addShortcut(app: App): void;
    killself(): void;
    updateTaskbar(): void;
}
