declare class FilesAPI {
    open: (path: string) => Promise<void>;
    set(path: string, extension: string): void;
}
