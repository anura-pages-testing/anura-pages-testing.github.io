declare class Bootsplash {
    element: any;
    constructor();
}
