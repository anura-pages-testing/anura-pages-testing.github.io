declare class ContextMenu {
    element: any;
    constructor();
    show(): void;
}
