declare class WMAPI {
    windows: WeakRef<WMWindow>[];
    create(ctx: App, info: object, onfocus?: (() => void) | null, onresize?: ((w: number, h: number) => void) | null, onclose?: (() => void) | null): WMWindow;
}
