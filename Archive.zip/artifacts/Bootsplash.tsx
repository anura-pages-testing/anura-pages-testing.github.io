class Bootsplash {
    element = (
        <div class="bootsplash">
            <img src="/assets/images/bootsplash.png" />
        </div>
    );
    constructor() {}
}
