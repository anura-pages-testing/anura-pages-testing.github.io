declare let V86Starter: V86StarterType;
// [todo]
type V86StarterType = any;
