declare namespace JSX {
    type IntrinsicElements = {
        [index: string]: any;
    };
}
declare let __effects: any;
declare class React {
    static get use(): (sink: any, mapping?: (...args: any[]) => any) => any;
    static createElement(type: string, props: {
        [index: string]: any;
    } | null, ...children: (HTMLElement | string)[]): HTMLElement;
}
declare function deepEqual(object1: any, object2: any): boolean;
declare function isObject(object: any): boolean;
declare function __assign_prop(elm: HTMLElement, name: string, prop: any): void;
declare function stateful<T>(target: T): T;
declare function handle(used: [any, any, any][], callback: (val: any) => void): void;
declare class styled {
    static new(strings: TemplateStringsArray, ...values: any): string;
    static parse_css(uid: string, css: string): string;
}
declare let css: string;
