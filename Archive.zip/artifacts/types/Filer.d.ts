declare let Filer: FilerType;
declare let $el: any;
// [TODO]
type FilerFS = any;
type FilerType = any;
