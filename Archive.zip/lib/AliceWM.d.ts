/**
 * the purpose of the following code is to give a demo of
 * how to realize the floating dialog using javascript.
 *It was written without any consideration of cross-browser compatibility,
 * and it can be run successfully under the firefox 3.5.7.
 *
 * nope nope this code has NOT been stolen rafflesia did NOT make it :thumbsup:
 */
/**
 * to show a floating dialog displaying the given dom element
 * @param {Object} title "title of the dialog"
 */
declare const windowInformation: {};
declare const windowID = 0;
declare class WindowInformation {
    title: string;
    width: string;
    minwidth: number;
    height: string;
    minheight: number;
    allowMultipleInstance: boolean;
}
declare class WMWindow {
    element: HTMLElement;
    content: HTMLElement;
    maximized: boolean;
    oldstyle: string | null;
    dragging: boolean;
    originalLeft: number;
    originalTop: number;
    width: number;
    height: number;
    mouseLeft: number;
    mouseTop: number;
    wininfo: WindowInformation;
    state: {
        title: string;
    };
    onfocus: () => void;
    onresize: (w: number, h: number) => void;
    onclose: () => void;
    justresized: boolean;
    mouseover: boolean;
    maximizeImg: HTMLImageElement;
    constructor(wininfo: WindowInformation);
    handleDrag(evt: MouseEvent): void;
    focus(): void;
    close(): void;
    togglemaximize(): void;
    maximize(): void;
    unmaximize(): Promise<void>;
    minimize(): void;
    unminimize(): void;
}
declare const AliceWM: {
    create: (givenWinInfo: string | WindowInformation) => WMWindow;
};
declare function deactivateFrames(): void;
declare function reactivateFrames(): void;
declare function getHighestZindex(): number;
declare function normalizeZindex(): Promise<void>;
/**
 * place the given dom element in the center of the browser window
 * @param {Object} element
 */
declare function center(element: HTMLElement): void;
/**
 * callback function for the dialog closed event
 * @param {Object} container
 */
